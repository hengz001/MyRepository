package sino.java.serviceimpl;

import sino.java.service.UserService;

public class UserServiceImpl implements UserService{

	public void save() {
		System.out.println("UserServiceImpl");
	}

}
