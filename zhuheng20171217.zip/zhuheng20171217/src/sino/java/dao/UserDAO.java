package sino.java.dao;

import sino.java.po.User;

public interface UserDAO {
	public void save(User user);
}
