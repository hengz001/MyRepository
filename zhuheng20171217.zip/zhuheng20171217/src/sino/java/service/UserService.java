package sino.java.service;

public interface UserService {
	public void save();
}	
